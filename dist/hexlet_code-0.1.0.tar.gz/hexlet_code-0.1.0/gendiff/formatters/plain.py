def format_diff_as_plain(diff):
    """Format the diff as plain text.

    Args:
        diff: The diff to format.

    Returns:
        A plain text representation of the diff.
    """
    def build_diff_string(key, diff_type, value=None):
        if diff_type == 'added':
            return "Property '{0}' was added with value: {1}".format(key, format_value(value))
        elif diff_type == 'deleted':
            return "Property '{0}' was removed".format(key)
        elif diff_type == 'updated':
            old_value, new_value = value
            return "Property '{0}' was updated. From {1} to {2}".format(key, format_value(old_value), format_value(new_value))
        else:
            return ""

    def format_value(value):
        if isinstance(value, dict):
            return "[complex value]"
        elif isinstance(value, str):
            return "'{0}'".format(value)
        else:
            return str(value)

    def build_strings(data, parent=''):
        strings = []
        for key, value in data.items():
            full_key = "{0}.{1}".format(parent, key) if parent else key
            diff_type, diff_value = value
            if isinstance(diff_value, dict):
                strings.extend(build_strings(diff_value, full_key))
            else:
                diff_string = build_diff_string(full_key, diff_type, diff_value)
                if diff_string:
                    strings.append(diff_string)
        return strings

    strings = build_strings(diff)
    return "\n".join(strings)
