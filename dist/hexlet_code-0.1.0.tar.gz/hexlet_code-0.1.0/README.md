### Hexlet tests and linter status:
[![Actions Status](https://github.com/HardDuck69/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/HardDuck69/python-project-50/actions)
Example of comparing .json files:
[![asciicast](https://asciinema.org/a/l98qgZGwXBTSXo1nNZzxC8PkM.svg)](https://asciinema.org/a/l98qgZGwXBTSXo1nNZzxC8PkM)
