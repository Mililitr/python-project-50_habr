### Hexlet tests and linter status:
[![Actions Status](https://github.com/HardDuck69/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/HardDuck69/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/1c6c7e5e679dc174040d/maintainability)](https://codeclimate.com/github/HardDuck69/python-project-50/maintainability)
[![github-actions](https://github.com/HardDuck69/python-project-50/actions/workflows/github-actions.yml/badge.svg)](https://github.com/HardDuck69/python-project-50/actions/workflows/github-actions.yml)
[![Test Coverage](https://api.codeclimate.com/v1/badges/1c6c7e5e679dc174040d/test_coverage)](https://codeclimate.com/github/HardDuck69/python-project-50/test_coverage)

Example of comparing .json files:
[![asciicast](https://asciinema.org/a/MbmuxpTLRrDZZ2uw9Fuf41VqZ.svg)](https://asciinema.org/a/MbmuxpTLRrDZZ2uw9Fuf41VqZ)

Example of comparing yaml files:
[![asciicast](https://asciinema.org/a/z626PWLq6ujYEm2nk4Rz4Vknf.svg)](https://asciinema.org/a/z626PWLq6ujYEm2nk4Rz4Vknf)

The cleanest lint-result ever:
[![asciicast](https://asciinema.org/a/T3DaJUoa764SQxdMoiQT2f8ze.svg)](https://asciinema.org/a/T3DaJUoa764SQxdMoiQT2f8ze)

Tests launch:
[![asciicast](https://asciinema.org/a/C7dTT9R2O5DUkp4fNPXG4TclA.svg)](https://asciinema.org/a/C7dTT9R2O5DUkp4fNPXG4TclA)
