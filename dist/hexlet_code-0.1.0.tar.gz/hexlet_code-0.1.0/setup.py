# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['gendiff = gendiff.cli:main --format=json']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/HardDuck69/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/HardDuck69/python-project-50/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/1c6c7e5e679dc174040d/maintainability)](https://codeclimate.com/github/HardDuck69/python-project-50/maintainability)\n[![github-actions](https://github.com/HardDuck69/python-project-50/actions/workflows/github-actions.yml/badge.svg)](https://github.com/HardDuck69/python-project-50/actions/workflows/github-actions.yml)\n[![Test Coverage](https://api.codeclimate.com/v1/badges/1c6c7e5e679dc174040d/test_coverage)](https://codeclimate.com/github/HardDuck69/python-project-50/test_coverage)\n\nExample of comparing .json files:\n[![asciicast](https://asciinema.org/a/MbmuxpTLRrDZZ2uw9Fuf41VqZ.svg)](https://asciinema.org/a/MbmuxpTLRrDZZ2uw9Fuf41VqZ)\n\nExample of comparing yaml files:\n[![asciicast](https://asciinema.org/a/z626PWLq6ujYEm2nk4Rz4Vknf.svg)](https://asciinema.org/a/z626PWLq6ujYEm2nk4Rz4Vknf)\n\nThe cleanest lint-result ever:\n[![asciicast](https://asciinema.org/a/T3DaJUoa764SQxdMoiQT2f8ze.svg)](https://asciinema.org/a/T3DaJUoa764SQxdMoiQT2f8ze)\n\nTests launch:\n[![asciicast](https://asciinema.org/a/C7dTT9R2O5DUkp4fNPXG4TclA.svg)](https://asciinema.org/a/C7dTT9R2O5DUkp4fNPXG4TclA)\n',
    'author': 'HardDuck69',
    'author_email': 'tmu1408@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
