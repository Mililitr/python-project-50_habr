# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['gendiff = gendiff.cli:main --format=json']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/HardDuck69/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/HardDuck69/python-project-50/actions)\nExample of comparing .json files:\n[![asciicast](https://asciinema.org/a/l98qgZGwXBTSXo1nNZzxC8PkM.svg)](https://asciinema.org/a/l98qgZGwXBTSXo1nNZzxC8PkM)\n',
    'author': 'HardDuck69',
    'author_email': 'tmu1408@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
